# How to use Router Scan

  [VIDEO](https://youtu.be/l6mBzICAX_A)
